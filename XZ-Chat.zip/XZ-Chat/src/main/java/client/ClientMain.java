package client;

import client.frame.LoginFrame;

public class ClientMain {
    public static void main(String[] args) {
        LoginFrame loginFrame = new LoginFrame();
        loginFrame.setVisible(true);
//        TestFrame testFrame = new TestFrame();
//        testFrame.setVisible(true);
    }
}
