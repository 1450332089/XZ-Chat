package client.mapper;

import client.pojo.User;

import java.util.Map;

public interface UserMapper {
    public String logIn(int id);
    public int addUser(User user);
    public int updateName(Map<String,Object> map);
    public String getName(int id);
}
